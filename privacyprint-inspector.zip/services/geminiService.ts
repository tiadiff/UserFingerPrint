import { GoogleGenAI } from "@google/genai";
import { FingerprintResult } from "../utils/fingerprinting";

export const generatePrivacyReport = async (fingerprintData: FingerprintResult): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API Key not found");
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Construct a prompt that explains the raw data
    const prompt = `
      Act as a cybersecurity expert and privacy advocate. Analyze the following browser fingerprinting data collected from a user's browser.
      
      Explain to the user how "unique" their browser looks based on this data. Use simple terms but cover technical details.
      
      Data:
      - Screen Resolution: ${fingerprintData.screen.width}x${fingerprintData.screen.height}
      - Screen Color Depth: ${fingerprintData.screen.colorDepth}
      - WebGL Vendor: ${fingerprintData.webgl.vendor}
      - WebGL Renderer: ${fingerprintData.webgl.renderer}
      - WebGL Unmasked Vendor: ${fingerprintData.webgl.unmaskedVendor}
      - WebGL Unmasked Renderer: ${fingerprintData.webgl.unmaskedRenderer}
      - Hardware Concurrency: ${fingerprintData.hardware.concurrency}
      - Device Memory: ${fingerprintData.hardware.memory}
      - Platform: ${fingerprintData.hardware.platform}
      - Timezone: ${fingerprintData.hardware.timezone}
      
      Structure your response in Markdown:
      1. **Uniqueness Assessment**: How easy is it to identify this specific device?
      2. **Key Identifiers**: Which specific data points above are the most "revealing" (e.g., a rare GPU renderer or specific resolution).
      3. **Privacy Implications**: Briefly explain how advertisers use this to track users across "Incognito" mode.
      4. **Defensive Measures**: Suggest 2-3 ways to mitigate this (e.g., specific browser settings, extensions, or browsers like Tor).
      
      Keep the tone educational and empowering.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Could not generate analysis.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};